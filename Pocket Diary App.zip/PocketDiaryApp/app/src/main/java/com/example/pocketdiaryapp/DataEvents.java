package com.example.pocketdiaryapp;

import java.util.ArrayList;

import Model.Event;

//Класс для формирования списка МЕРОПРИЯТИЕ
public class DataEvents {

    String dateEvent;
    ArrayList<Event> eventArrayList;

    //Конструкторы объекта Мероприятие
    public DataEvents( String dateEvent, ArrayList<Event> eventArrayList){
        this.dateEvent = dateEvent;
        this.eventArrayList = eventArrayList;

    }
    public DataEvents(){

    }


    public String getDateEvent() {
        return dateEvent;
    }
    public ArrayList<Event> getEventArrayList() {
        return eventArrayList ;
    }



    public void setDateEvent(String dateEvent) {
        this.dateEvent = dateEvent;
    }
    public void setEvent(ArrayList<Event> eventArrayList) {
        this.eventArrayList = eventArrayList;
    }

}


