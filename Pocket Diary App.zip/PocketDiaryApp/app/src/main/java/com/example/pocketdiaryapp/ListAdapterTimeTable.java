package com.example.pocketdiaryapp;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import Model.Event;

public class ListAdapterTimeTable extends ArrayAdapter<DataEvents> {

    private static final String TAG = "ListAdapterTimeTable";
    private LayoutInflater inflater;
    private ArrayList<DataEvents> listDataEventslocal;
    //private ArrayList<Event> eventArrayList;
    private Context context;
    int resourse;
    private ListAdapter item_list_adapter;

    public ListAdapterTimeTable(@NonNull Context context, int resource, ArrayList<DataEvents> listEventsOneDay) {
        super(context, resource, listEventsOneDay);
        this.context = context;
        this.resourse = resource;
        this.listDataEventslocal = new ArrayList<>(listEventsOneDay);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        String date = getItem(position).getDateEvent();
        ArrayList<Event> eventArrayList = getItem(position).getEventArrayList();

        LayoutInflater inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(resourse, parent, false);

        ViewHolder viewHolder = new ViewHolder();
        viewHolder.dataEvent = (TextView) convertView.findViewById(R.id.data_event);
        viewHolder.eventlist = (ListView) convertView.findViewById(R.id.list_items);

        viewHolder.dataEvent.setText(date);

        item_list_adapter = new ItemListAdapter(context, R.layout.item_design_timetable, eventArrayList);
        viewHolder.eventlist.setAdapter(item_list_adapter);

        return convertView;
    }

    private class ViewHolder{
        TextView dataEvent;
        ListView eventlist;
    }
}
