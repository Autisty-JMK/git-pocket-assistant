package com.example.pocketdiaryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.util.List;

import Data.DataBaseHandler;
import Model.Event;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DataBaseHandler dataBaseHandler = new DataBaseHandler(this);

        /*
        dataBaseHandler.addEvent(new Event("Концерт", "09.10.2022", "10:00"));

        List<Event> eventList = dataBaseHandler.getAllEvent();

        for(Event event : eventList){
            Log.d("Event ", "ID: " + event.getId() + " name:" + event.getName() +" date: " + event.getDate() + " time: " + event.getTime());
        }

        Event event = dataBaseHandler.getEvent(1);
        event.setName("Выставка");
        event.setDate("12.11.2022");
        event.setTime("15:30");
        dataBaseHandler.updateEvent(event);

        List<Event> eventList = dataBaseHandler.getAllEvent();

        for(Event event1 : eventList){
            Log.d("Event ", "ID: " + event1.getId() + " name:" + event1.getName() +" date: " + event1.getDate() + " time: " + event1.getTime());
        }
        */
    }

    public void goTimetable(View view){
        Intent intent = new Intent(this, Timetable.class);
        startActivity(intent);

    }
}