package com.example.pocketdiaryapp;

public class ItemEvent {

    String nameEvent;
    String timeEvent;
}
