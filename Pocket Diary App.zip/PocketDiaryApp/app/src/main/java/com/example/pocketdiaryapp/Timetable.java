package com.example.pocketdiaryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.LogPrinter;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import Model.Event;

public class Timetable extends AppCompatActivity {
    private ListView listView;
    private Event event;
    private DataEvents dataEvents;
    private ArrayList<Event> listEvents;
    private ArrayList<DataEvents> listEventsOneDay = new ArrayList<>();
    private ListAdapterTimeTable adapter_timeTable;

    //Создание окна списка мероприятий
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable);
        listView = findViewById(R.id.list_timeTable);

        //цикл генерации мероприятий
        for(int i = 0; i < 5; i++ ){

            listEvents = new ArrayList<>();
            for(int j = 0; j < 5; j++){
                event = new Event("event"+i+j, "time"+i+j,"name"+i+j);
                listEvents.add(event);
            }
            dataEvents = new DataEvents("data"+i, listEvents);
            listEventsOneDay.add(dataEvents);

        }
        /*for(DataEvents dataEvents : listEventsOneDay) {
            ArrayList<Event> events = dataEvents.getEventArrayList();
            for (Event event : events) {
                Log.d("Evet: ", dataEvents.getDateEvent() + event.getTime() );
            }
        }*/
         adapter_timeTable = new ListAdapterTimeTable(this, R.layout.list_design_timetable, listEventsOneDay);
        listView.setAdapter(adapter_timeTable);
    }
    //Переход на главное окно
    private void closeActivity() {
        this.finish();
    }

    public void goMain(View view){
        closeActivity();
        /*Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);*/
    }

    public void goAddEvent(View view) {
        Intent intent1 = new Intent(this, AddEvent.class);
        startActivity(intent1);
    }


}