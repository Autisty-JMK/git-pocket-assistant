package com.example.pocketdiaryapp;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class AddEvent extends AppCompatActivity implements View.OnClickListener{

    private EditText editTextDate, editTextTime;
    private Button btnClose, btnSave;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.add_events);

        editTextDate = (EditText) findViewById(R.id.editDatatext);
        editTextTime = (EditText) findViewById(R.id.editTimetext);
        btnClose = (Button) findViewById(R.id.btnClose);
        btnSave = (Button) findViewById(R.id.btnSave);


        editTextDate.setOnClickListener(this);
        editTextTime.setOnClickListener(this);
        btnClose.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();

        switch (id) {
            case R.id.editDatatext:
                // вызываем диалог с выбором даты
                TimeDataPicker.callDatePicker(this, editTextDate);
                break;
            case R.id.editTimetext:
                // вызываем диалог с выбором времени
                TimeDataPicker.callTimePicker(this,editTextTime);
                break;
            case R.id.btnClose:
                // закрываем окно
                this.finish();
                break;
            case R.id.btnSave:
                // вызываем сохранение

                break;
        }
    }


}
