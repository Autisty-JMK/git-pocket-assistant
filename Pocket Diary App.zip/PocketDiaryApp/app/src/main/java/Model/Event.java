package Model;

//Класс объекта Мероприятие
public class Event {

    private int id;
    private String date;
    private String name;
    private String time;

    //Конструктор класса пустой
    public Event() {
    }

    //Конструктор класса 4 переменные
    public Event(int id, String date, String time, String name) {
        this.id = id;
        this.date = date;
        this.time = time;
        this.name = name;

    }

    //Конструктор класса 3 переменные
    public Event(String date, String time, String name) {
        this.date = date;
        this.time = time;
        this.name = name;

    }

    //НАЧАЛО Геттеры переменных
    public int getId() {
        return id;
    }
    public String getDate() {
        return date;
    }
    public String getName() {
        return name;
    }
    public String getTime() {
        return time;
    }

    public String getDateTime(){
        return date+" "+time;
    }
    //КОНЕЦ Геттеры переменных

    //НАЧАЛО Сеттеры переменных
    public void setId(int id) {
        this.id = id;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setTime(String time) {
        this.time = time;
    }

    public void setDateTime(String dataTime){
        String[] data_time = dataTime.split(" ");
        this.date = data_time[0];
        this.time = data_time[1];
    }

    //КОНЕЦ Сеттеры переменных
}
