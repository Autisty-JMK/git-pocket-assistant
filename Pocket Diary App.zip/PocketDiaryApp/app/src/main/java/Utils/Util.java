package Utils;

public class Util {

    public static final int DATABASAE_VERSION = 1;
    public static final String DATABASAE_NAME = "eventsDB";
    public static final String TABLE_NAME = "events";

    public static final String KEY_ID = "id";
    public static final String KEY_NAME_EVENT = "nameEvent";
    public static final String KEY_TIME_AND_DATA_EVENT = "timeAndDataEvent";
}
